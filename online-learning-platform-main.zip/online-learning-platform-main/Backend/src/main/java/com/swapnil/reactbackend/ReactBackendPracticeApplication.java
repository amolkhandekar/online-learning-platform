package com.swapnil.reactbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactBackendPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactBackendPracticeApplication.class, args);
	}

}
