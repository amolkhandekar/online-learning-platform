package com.swapnil.reactbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactBackendPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
